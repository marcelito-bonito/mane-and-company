// Transcribed and visually checked against all four pages of the supplied menu. Prices in MXN.
// carta and bebidas are navigation groupings: these blocks have no named heading in the PDF.
window.MENU_DATA = {
  "currency": "MXN",
  "source": "assets/menu-original.pdf",
  "categories": [
    {
      "id": "chilaquiles",
      "label": {
        "es": "Chilaquiles",
        "en": "Chilaquiles"
      },
      "page": 1,
      "editorialGrouping": false
    },
    {
      "id": "huevos",
      "label": {
        "es": "Huevos",
        "en": "Eggs"
      },
      "page": 1,
      "editorialGrouping": false
    },
    {
      "id": "extras",
      "label": {
        "es": "Extras",
        "en": "Extras"
      },
      "page": 1,
      "editorialGrouping": false
    },
    {
      "id": "carta",
      "label": {
        "es": "Más de la carta",
        "en": "More from the menu"
      },
      "page": 2,
      "editorialGrouping": true
    },
    {
      "id": "hotcakes",
      "label": {
        "es": "Hot Cakes",
        "en": "Pancakes"
      },
      "page": 2,
      "editorialGrouping": false
    },
    {
      "id": "sandwiches",
      "label": {
        "es": "Sandwiches",
        "en": "Sandwiches"
      },
      "page": 3,
      "editorialGrouping": false
    },
    {
      "id": "combos",
      "label": {
        "es": "Combos",
        "en": "Combos"
      },
      "page": 3,
      "editorialGrouping": false
    },
    {
      "id": "ninos",
      "label": {
        "es": "Niños",
        "en": "Children"
      },
      "page": 3,
      "editorialGrouping": false
    },
    {
      "id": "cafe",
      "label": {
        "es": "Café",
        "en": "Coffee"
      },
      "page": 4,
      "editorialGrouping": false
    },
    {
      "id": "te",
      "label": {
        "es": "Té",
        "en": "Tea"
      },
      "page": 4,
      "editorialGrouping": false
    },
    {
      "id": "bebidas",
      "label": {
        "es": "Bebidas",
        "en": "Drinks"
      },
      "page": 4,
      "editorialGrouping": true
    },
    {
      "id": "mimosas",
      "label": {
        "es": "Mimosas",
        "en": "Mimosas"
      },
      "page": 4,
      "editorialGrouping": false
    }
  ],
  "items": [
    {
      "id": "m01",
      "category": "chilaquiles",
      "name": "Clásicos",
      "price": 160,
      "description": {
        "es": "Guarnición de frijoles refritos, queso, crema, y papas en salsa",
        "en": "Served with refried beans, cheese, crema and potatoes in sauce."
      },
      "variants": [
        {
          "label": {
            "es": "Media",
            "en": "Half portion"
          },
          "price": 120
        }
      ]
    },
    {
      "id": "m02",
      "category": "chilaquiles",
      "name": "Mané",
      "price": 225,
      "description": {
        "es": "Acompañados con pollo, 2 guisos, guarnición de frijoles refritos, queso, crema y papas en salsa. Guisos: Chicharron en salsa, cortadillo de res, milanesa de res",
        "en": "Served with chicken, two prepared meat dishes, refried beans, cheese, crema and potatoes in sauce. Choose from pork cracklings in sauce, beef stew or breaded beef."
      },
      "variants": [
        {
          "label": {
            "es": "Media",
            "en": "Half portion"
          },
          "price": 185
        }
      ]
    },
    {
      "id": "m03",
      "category": "huevos",
      "name": "Omelette",
      "price": 199,
      "description": {
        "es": "Relleno de espinaca, champiñones, queso, y cebolla morada acompañado con espárrago y tomates salteados",
        "en": "Filled with spinach, mushrooms, cheese and red onion, served with asparagus and sautéed tomatoes."
      }
    },
    {
      "id": "m04",
      "category": "huevos",
      "name": "Montados",
      "price": 169,
      "description": {
        "es": "Dos empalmes de maíz con chicharron prensado montados con dos huevos estrellados en salsa roja y verde, y frijoles refritos",
        "en": "Two corn-tortilla stacks with pressed pork cracklings, topped with two fried eggs, red and green sauces, and refried beans."
      }
    },
    {
      "id": "m05",
      "category": "huevos",
      "name": "Divorciados",
      "price": 139,
      "description": {
        "es": "Huevos estrellados en salsa verde y roja acompañados con frijoles refritos y tortillas",
        "en": "Fried eggs with green and red sauces, served with refried beans and tortillas."
      }
    },
    {
      "id": "m06",
      "category": "huevos",
      "name": "Al Gusto",
      "price": 129,
      "description": {
        "es": "Revueltos o estrellados acompañados con frijoles refritos y tortillas",
        "en": "Scrambled or fried eggs, served with refried beans and tortillas."
      }
    },
    {
      "id": "m07",
      "category": "extras",
      "name": "Chicharron en Salsa",
      "price": 45,
      "description": {
        "es": "",
        "en": "Pork cracklings in sauce"
      }
    },
    {
      "id": "m08",
      "category": "extras",
      "name": "Cortadillo de Res",
      "price": 45,
      "description": {
        "es": "",
        "en": "Beef stew"
      }
    },
    {
      "id": "m09",
      "category": "extras",
      "name": "Milanesa de Res",
      "price": 45,
      "description": {
        "es": "",
        "en": "Breaded beef"
      }
    },
    {
      "id": "m10",
      "category": "extras",
      "name": "Pollo a la Plancha",
      "price": 45,
      "description": {
        "es": "",
        "en": "Grilled chicken"
      }
    },
    {
      "id": "m11",
      "category": "extras",
      "name": "Chorizo",
      "price": 50,
      "description": {
        "es": "",
        "en": "Chorizo"
      }
    },
    {
      "id": "m12",
      "category": "extras",
      "name": "Huevo",
      "price": 20,
      "description": {
        "es": "",
        "en": "Egg"
      }
    },
    {
      "id": "m13",
      "category": "extras",
      "name": "Tortillas",
      "price": 25,
      "description": {
        "es": "",
        "en": "Tortillas"
      }
    },
    {
      "id": "m14",
      "category": "extras",
      "name": "Aguacate",
      "price": 25,
      "description": {
        "es": "",
        "en": "Avocado"
      }
    },
    {
      "id": "m15",
      "category": "extras",
      "name": "Papas a la Francesa",
      "price": 65,
      "description": {
        "es": "",
        "en": "French fries"
      }
    },
    {
      "id": "m16",
      "category": "extras",
      "name": "Papa Hash Brown",
      "price": 40,
      "description": {
        "es": "",
        "en": "Hash brown"
      }
    },
    {
      "id": "m17",
      "category": "carta",
      "name": "Machacado",
      "price": 159,
      "description": {
        "es": "Natural o salseado",
        "en": "Dried shredded beef, plain or with sauce."
      }
    },
    {
      "id": "m18",
      "category": "carta",
      "name": "Taco Canasta",
      "price": 18,
      "description": {
        "es": "Chicharron Prensado / Frijoles",
        "en": "Basket taco with pressed pork cracklings or beans."
      }
    },
    {
      "id": "m19",
      "category": "carta",
      "name": "Quesadillas Cielo",
      "price": 165,
      "description": {
        "es": "Tortilla azul de maíz rellena de queso acompañada con crema y aguacate",
        "en": "Blue-corn tortilla filled with cheese, served with crema and avocado."
      }
    },
    {
      "id": "m20",
      "category": "carta",
      "name": "Bowl de Frutas",
      "price": 70,
      "description": {
        "es": "Fruta fresca de temporada",
        "en": "Fresh seasonal fruit."
      }
    },
    {
      "id": "m21",
      "category": "carta",
      "name": "Berry Yogurt Bowl",
      "price": 155,
      "description": {
        "es": "Yogurt natural con fresa, moras, granola mixta, y cacao",
        "en": "Plain yogurt with strawberries, berries, mixed granola and cacao."
      }
    },
    {
      "id": "m22",
      "category": "carta",
      "name": "Avo Toast",
      "price": 189,
      "description": {
        "es": "Aguacate, tocino, queso panela, y tomate cherry montado en pan brioche",
        "en": "Brioche topped with avocado, bacon, panela cheese and cherry tomatoes."
      }
    },
    {
      "id": "m23",
      "category": "hotcakes",
      "name": "Old Fashioned",
      "price": 189,
      "description": {
        "es": "Tres hot cakes con mantequilla, tocino y jarabe de maple acompañados con papa hash brown",
        "en": "Three pancakes with butter, bacon and maple syrup, served with a hash brown."
      }
    },
    {
      "id": "m24",
      "category": "hotcakes",
      "name": "Nutella",
      "price": 199,
      "description": {
        "es": "Tres hot cakes con fresa, moras, Nutella, y cacao",
        "en": "Three pancakes with strawberries, berries, Nutella and cacao."
      }
    },
    {
      "id": "m25",
      "category": "hotcakes",
      "name": "Primavera",
      "price": 169,
      "description": {
        "es": "Tres hot cakes con fresa, moras, mermelada de temporada, y cacao",
        "en": "Three pancakes with strawberries, berries, seasonal jam and cacao."
      }
    },
    {
      "id": "m26",
      "category": "sandwiches",
      "name": "Serrano",
      "price": 199,
      "description": {
        "es": "Relleno de huevo, jamón serrano, aderezo de la casa, y queso acompañado con papa hash brown",
        "en": "Filled with egg, serrano ham, house dressing and cheese, served with a hash brown."
      }
    },
    {
      "id": "m27",
      "category": "sandwiches",
      "name": "Sunny",
      "price": 189,
      "description": {
        "es": "Relleno de huevo, tocino, aderezo de la casa, y queso acompañado con papa hash brown",
        "en": "Filled with egg, bacon, house dressing and cheese, served with a hash brown."
      }
    },
    {
      "id": "m28",
      "category": "sandwiches",
      "name": "Milano",
      "price": 189,
      "description": {
        "es": "Pollo grill, queso, tomate, y espinaca en aderezo de la casa con papas a la francesa",
        "en": "Grilled chicken, cheese, tomato and spinach with house dressing, served with French fries."
      }
    },
    {
      "id": "m29",
      "category": "sandwiches",
      "name": "London",
      "price": 189,
      "description": {
        "es": "Pechuga de pavo, queso, tomate, y espinaca en aderezo de la casa con papas a la francesa",
        "en": "Turkey breast, cheese, tomato and spinach with house dressing, served with French fries."
      }
    },
    {
      "id": "m30",
      "category": "sandwiches",
      "name": "Toledo",
      "price": 189,
      "description": {
        "es": "Jamón serrano, queso, tomate, y espinaca en aderezo de la casa con papas a la francesa",
        "en": "Serrano ham, cheese, tomato and spinach with house dressing, served with French fries."
      }
    },
    {
      "id": "m31",
      "category": "sandwiches",
      "name": "Berlin",
      "price": 159,
      "description": {
        "es": "Champiñones, queso, tomate, y espinaca en aderezo de la casa con papas a la francesa",
        "en": "Mushrooms, cheese, tomato and spinach with house dressing, served with French fries."
      }
    },
    {
      "id": "m32",
      "category": "combos",
      "name": "Chilaquiles",
      "price": 225,
      "description": {
        "es": "Bowl de Fruta Medio / Chilaquiles Clásicos Media Orden / Café Refill",
        "en": "Half fruit bowl, half order of Clásicos chilaquiles, and refill coffee."
      }
    },
    {
      "id": "m33",
      "category": "combos",
      "name": "Huevos",
      "price": 210,
      "description": {
        "es": "Bowl de Fruta Medio / Huevos al gusto con frijoles y tortillas / Café Refill",
        "en": "Half fruit bowl, eggs your way with beans and tortillas, and refill coffee."
      }
    },
    {
      "id": "m34",
      "category": "ninos",
      "name": "Quesadillas",
      "price": 110,
      "description": {
        "es": "Tres quesadillas en tortilla de maíz o harina acompañados con frijoles refritos",
        "en": "Three quesadillas in corn or flour tortillas, served with refried beans."
      }
    },
    {
      "id": "m35",
      "category": "ninos",
      "name": "Taquitos",
      "price": 115,
      "description": {
        "es": "Cuatro taquitos de guiso a elección: Huevo, Frijoles, Cortadillo, Chicharron, o Huevo con Jamón",
        "en": "Four small tacos with your choice of egg, beans, beef stew, pork cracklings, or egg with ham."
      }
    },
    {
      "id": "m36",
      "category": "ninos",
      "name": "Mini Hot Cakes",
      "price": 100,
      "description": {
        "es": "Tres mini hot cakes acompañados con tocino, mantequilla, y jarabe de maple",
        "en": "Three mini pancakes served with bacon, butter and maple syrup."
      }
    },
    {
      "id": "m37",
      "category": "ninos",
      "name": "Huevo Peque",
      "price": 90,
      "description": {
        "es": "Dos huevos revueltos acompañados con frijoles refritos. Huevo con Jamón + $15",
        "en": "Two scrambled eggs served with refried beans. Add ham: + $15 MXN."
      }
    },
    {
      "id": "m38",
      "category": "cafe",
      "name": "Americano",
      "price": 49,
      "description": {
        "es": "Refill",
        "en": "Refill"
      }
    },
    {
      "id": "m39",
      "category": "cafe",
      "name": "Descafeinado",
      "price": 49,
      "description": {
        "es": "Refill",
        "en": "Decaffeinated coffee, refill"
      }
    },
    {
      "id": "m40",
      "category": "cafe",
      "name": "En las Rocas",
      "price": 59,
      "description": {
        "es": "",
        "en": "Coffee on the rocks"
      }
    },
    {
      "id": "m41",
      "category": "cafe",
      "name": "Latte",
      "price": 65,
      "description": {
        "es": "",
        "en": ""
      }
    },
    {
      "id": "m42",
      "category": "cafe",
      "name": "Capuchino",
      "price": 60,
      "description": {
        "es": "",
        "en": "Cappuccino"
      }
    },
    {
      "id": "m43",
      "category": "te",
      "name": "Tetera",
      "price": 110,
      "description": {
        "es": "Hoja suelta té verde Japonés / Hoja suelta té negro Inglés",
        "en": "Teapot: loose-leaf Japanese green tea or English black tea."
      }
    },
    {
      "id": "m44",
      "category": "te",
      "name": "Taza",
      "price": 40,
      "description": {
        "es": "Verde / Manzanilla / Hierba Buena / Negro",
        "en": "Cup: green tea, chamomile, mint or black tea."
      }
    },
    {
      "id": "m45",
      "category": "bebidas",
      "name": "Jugo de Naranja",
      "price": 49,
      "description": {
        "es": "",
        "en": "Orange juice"
      }
    },
    {
      "id": "m46",
      "category": "bebidas",
      "name": "Jugo Verde",
      "price": 49,
      "description": {
        "es": "",
        "en": "Green juice"
      }
    },
    {
      "id": "m47",
      "category": "bebidas",
      "name": "Coca Cola",
      "price": 45,
      "description": {
        "es": "Regular - Light - Zero",
        "en": "Regular / Light / Zero"
      }
    },
    {
      "id": "m48",
      "category": "bebidas",
      "name": "Fresca",
      "price": 45,
      "description": {
        "es": "",
        "en": ""
      }
    },
    {
      "id": "m49",
      "category": "bebidas",
      "name": "Limonada",
      "price": 49,
      "description": {
        "es": "",
        "en": "Lemonade"
      }
    },
    {
      "id": "m50",
      "category": "bebidas",
      "name": "Limonada Mineral",
      "price": 59,
      "description": {
        "es": "",
        "en": "Sparkling lemonade"
      }
    },
    {
      "id": "m51",
      "category": "bebidas",
      "name": "Limonada de Fresa",
      "price": 64,
      "description": {
        "es": "",
        "en": "Strawberry lemonade"
      }
    },
    {
      "id": "m52",
      "category": "bebidas",
      "name": "Jamaica",
      "price": 49,
      "description": {
        "es": "",
        "en": "Hibiscus drink"
      }
    },
    {
      "id": "m53",
      "category": "bebidas",
      "name": "Botella de Agua",
      "price": 25,
      "description": {
        "es": "",
        "en": "Bottled water"
      }
    },
    {
      "id": "m54",
      "category": "mimosas",
      "name": "Botella",
      "price": 550,
      "description": {
        "es": "750 ml",
        "en": "750 ml bottle"
      }
    }
  ],
  "sauces": {
    "es": "Verde / Verde Cremosa / Roja / Chorizo / Chipotle",
    "en": "Green / Creamy green / Red / Chorizo / Chipotle"
  }
};