window.MANE_CONFIG = {
  "name": "Mané & Company",
  "telephone": "+528664078406",
  "phoneDisplay": "866 407 8406",
  "instagram": "https://www.instagram.com/maneandco_/",
  "maps": "https://www.google.com/maps/search/?api=1&query=Man%C3%A9+and+Company+Moctezuma+Av+Roble+Monclova",
  "directions": "https://www.google.com/maps/dir/?api=1&destination=Man%C3%A9+and+Company+Moctezuma+Av+Roble+Monclova",
  "hours": {
    "tuesdaySaturday": "08:00–13:00",
    "sunday": "09:00–14:00"
  },
  "whatsapp": "https://wa.me/528661657928",
  "reservationUrl": "https://wa.me/528661657928",
  "siteUrl": null,
  "streetAddress": "Esquina Moctezuma y Av. Roble, El Pueblo",
  "postalCode": "25730",
  "addressLocality": "Monclova",
  "addressRegion": "Coahuila",
  "addressCountry": "MX",
  "reviews": "https://share.google/F2VJAc9B2lnYGUUfW"
};
