# Mané & Company — Review version

Static ES/EN site. Open index.html with all folders alongside it. No install or build is required.

GitHub/Render: upload these files to a repository, create a Static Site, leave Build Command empty and set Publish Directory to `.`. Keep noindex until publication is approved.

Menu items, prices and PDF are unchanged. Reservations: WhatsApp only at +52 866 165 7928. Pickup: +52 866 407 8406.

The supplied Google review link is configured as provided; verify that it opens the review composer before public launch. Existing Maps routes are preserved.
