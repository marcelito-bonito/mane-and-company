# Fuentes y decisiones

Material principal: ZIP proporcionado por el propietario, con 32 JPG y menú de cuatro páginas. Fotografías originales utilizadas con la autorización del encargo; no se añadieron imágenes de stock. El logo completo se extrajo como imagen del PDF; el monograma verde corresponde a Untitled design.JPG.

El ZIP incluye el mismo tipo de material descrito para la carpeta de Drive; no se requirió descargar duplicados de Drive.

Fuentes consultadas el 5 de noviembre de 2026:
- https://localmexico.net/negocio/mane-and-company-monclova
- https://es.restaurantguru.com/Mane-and-Company-Monclova
- https://laprensadecoahuila.com.mx/2025/03/24/restaurante-desayunador-mane-company/

Dirección coincidente: Moctezuma y Av. Roble, Monclova; Local Mexico especifica El Pueblo y CP 25730. Teléfono coincidente en ambos directorios: +52 866 407 8406. Horarios contradictorios: omitidos. No se trasladaron calificaciones ni reseñas de agregadores.

Instagram: @maneandco_ consta en la cuarta página del menú y en el encargo. Enlace: https://www.instagram.com/maneandco_/ . No se pudo comprobar la carga del perfil mediante consulta automatizada.

Google Maps utiliza una consulta por nombre y dirección confirmados, no un identificador de ficha inventado. Las fotos de platos llevan leyendas neutrales; no se atribuyen nombres específicos sin correspondencia documentada.
